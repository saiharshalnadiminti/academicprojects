<!DOCTYPE html>
<html>

<head>
    <title> Footer </title>
</head>

<body>
    <div class="footer">
        <?php
	echo "<b>First Name :</b> Saiharshal ";
	echo "<br>";
	echo "<b>Last Name :</b> Nadiminti ";
	echo "<br>";
	echo "<b>Student Number :</b> 040982223 ";
	echo "<br>";
	echo "<b>Email :</b> nadi0009@algonquinlive.com";
	?>
    </div>
</body>

</html>