	<!DOCTYPE html>
	<html>

	<head>
	    <title> Header</title>
	</head>

	<body>
	    <div class="menu">
	        <?php
			echo '<a href="CreateAccount.php">Create Account &emsp; </a>';
			echo '<a href="Login.php">Login &emsp; </a>';
			echo '<a href="ViewAllEmployees.php"> ViewAllEmployees &emsp; </a>';
			
			?>
	    </div>
	</body>

	</html>