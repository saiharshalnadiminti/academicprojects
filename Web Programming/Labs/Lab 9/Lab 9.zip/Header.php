<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <title></title>
</head>

<body>
    <div class="header">
        <?php echo "Computer Engineering Technology- Computing Science"; ?>
        <?php echo "<br>"; ?>
        <?php echo "CST8238:Web Programming"; ?>
    </div>
</body>

</html>