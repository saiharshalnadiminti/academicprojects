<?php
header('Content-type: text/css; charset:UTF-8');
 ?>

.footer {
  color: black;
  line-height: 1.5em;
  padding: 20px;
  border-style: solid;
  border-color: black;
  border-width: 2px;
  height: 100px;
  font-size: 22px;
  line-height: 30px;
}
.content {
  color: black;
  line-height: 50px;
  padding: 20px;
  border-color: black;
  border-width: 2px;
  border-style: solid;
  font-size: 22px;
}
.header {
  color: black;
  border-color: black;
  text-align: center;
  height: 120px;
  font-size: 30px;
  border-width: 2px;
  border-style: solid;
  background-size: 10% 70%;
  background-repeat: no-repeat;
  background-position: right-top;
  backface-visibility: 50%;
}
.menu {
  color: black;
  line-height: 1.2em;
  padding: 10px;
  border-color: black;
  border-width: 2px;
  border-style: solid;
  margin-top: 40px;
  margin-left: 900px;
  margin-bottom: 0px;
  margin-right: 0px;
  font-size: 20px;
}
.prime{
  text-align: center;
}
