	<!DOCTYPE html>
	<html>
	<head>
		<title> Header</title>
	</head>
	<body>
		<div class="menu">
			<?php
			echo '<a href="Arrays.php">Arrays &emsp; </a>';
			echo '<a href="Currency.php">Currency &emsp; </a>';
			echo '<a href="Vehicle.php">Vehicle &emsp; </a>';
			?>
		</div>
</body>
</html>
