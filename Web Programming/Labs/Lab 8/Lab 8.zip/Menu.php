	<!DOCTYPE html>
	<html>

	<head>
	    <title> Header</title>
	</head>

	<body>
	    <div class="menu">
	        <?php
			echo '<a href="Input.php">Input &emsp; </a>';
			echo '<a href="Session1.php">Session 1 &emsp; </a>';
			echo '<a href="Session2.php">Session 2 &emsp; </a>';
			?>
	    </div>
	</body>

	</html>