	<!DOCTYPE html>
	<html>
	<head>
		<title> Header</title>
	</head>
	<body>
		<div class="menu">
			<?php
			echo '<a href="ChessBoard.php">ChessBoard &emsp; </a>';
			echo '<a href="Prime.php">Prime &emsp; </a>';
			echo '<a href="Pattern.php">Pattern &emsp; </a>';
			?>
		</div>
</body>
</html>
